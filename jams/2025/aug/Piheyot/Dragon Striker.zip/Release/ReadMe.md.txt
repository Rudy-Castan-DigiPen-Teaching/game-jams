1. Piheyot - Seungmin Hong
2. You as a knight have to take down all the dragons of the infinite grid and move far as you can.
3. 
Game Start : Enter
Game Retry : R

Ending Turn, Using Item : Mouse Left-Click
Player Movement : WASD

You can use items by mouse left-click and another mouse click to your designated tile.

WaterBucket : Makes the tile 'soaked', where dragon can't attack for 1 turn and can take away fire.

Boots : Can jump 2~3 tiles, but only in directions that you can face

Teleport : Can teleport to any tile you choose.

4. The tiles are only one-time use, and becomes purple, which will magically disappear when a turn gets skipped. You have to make sure you don't get caught by the tiles you've went through, while taking down all dragons.