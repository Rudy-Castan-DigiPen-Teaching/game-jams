<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="preview" tilewidth="32" tileheight="32" tilecount="729" columns="27">
 <image source="preview.png" width="894" height="864"/>
</tileset>
