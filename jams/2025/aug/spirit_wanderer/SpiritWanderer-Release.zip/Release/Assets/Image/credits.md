# Wanderer
- https://craftpix.net/freebies/free-swordsman-1-3-level-pixel-top-down-sprite-character-pack/

# Spirit
- https://opengameart.org/content/sparkling-fireball-effect

# Enemy 
https://craftpix.net/freebies/free-slime-mobs-pixel-art-top-down-sprite-pack/

# aura, aura_original
https://opengameart.org/content/auras

# HP, maxHP
https://opengameart.org/content/health-bars
