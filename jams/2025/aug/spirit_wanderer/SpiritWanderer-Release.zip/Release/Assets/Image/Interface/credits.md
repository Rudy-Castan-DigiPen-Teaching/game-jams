# Frame, HPFrame, HPFrameBack, TimerBar, TimerFrame, TimerFrameBack
https://tiopalada.itch.io/tiny-rpg-dragon-regalia-gui

# HPBar, TimerBar
https://opengameart.org/content/health-bars

# WandererPortraitl, WandererIdle
- https://craftpix.net/freebies/free-swordsman-1-3-level-pixel-top-down-sprite-character-pack/
