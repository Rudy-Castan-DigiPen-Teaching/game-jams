### ElectricAttack
https://frostwindz.itch.io/pixel-art-skill-animations-lightning \
This asset pack can be used in personal and commercial projects. \
You can modify the assets as you need. \
Credit is not necessary but is appreciated. \
You are not allowed to redistribute or resell the assets.

### FireAttack
https://opengameart.org/content/fire-wrath-magic-effect

### IceAttack
https://itch.io/queue/c/3852212/pixel-art-animations?game_id=3513347&password=

### NormalAttack, WindAttack
https://opengameart.org/content/pure-projectile-magic-effect




