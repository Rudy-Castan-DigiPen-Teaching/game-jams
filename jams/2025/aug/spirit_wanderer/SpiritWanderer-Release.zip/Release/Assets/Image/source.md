Wanderer
- https://craftpix.net/freebies/free-swordsman-1-3-level-pixel-top-down-sprite-character-pack/

Spirit
- https://opengameart.org/content/sparkling-fireball-effect
