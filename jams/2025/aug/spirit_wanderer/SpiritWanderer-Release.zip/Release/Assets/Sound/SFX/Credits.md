### Fire

https://opengameart.org/content/free-cinematic-sound-effects

Fire / Gregor Quendel - Designed Fire - Swooshes - Burst Evolving 19


------------------------------------------------------------------------

## pixabay license
https://pixabay.com/ko/service/license-summary/

### Wind
Sound Effect by <a href="https://pixabay.com/ko/users/yodguard-12455005/?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=378630">yodguard</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=378630">Pixabay</a>

### Ice
Sound Effect by <a href="https://pixabay.com/ko/users/creatorshome-49707711/?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=327726">CreatorsHome</a> from <a href="https://pixabay.com/sound-effects//?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=327726">Pixabay</a>

### Electric
Sound Effect by <a href="https://pixabay.com/users/dragon-studio-38165424/?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=386161">DRAGON-STUDIO</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=386161">Pixabay</a>


### Normal Attack
Sound Effect by <a href="https://pixabay.com/users/freesound_crunchpixstudio-49769582/?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=394505">Crunchpix Studio</a> from <a href="https://pixabay.com/sound-effects//?utm_source=link-attribution&utm_medium=referral&utm_campaign=music&utm_content=394505">Pixabay</a>


------------------------------------------------------------------------

### Damaged
Damage sound effect by Raclure -- https://freesound.org/s/458867/ -- License: Creative Commons 0