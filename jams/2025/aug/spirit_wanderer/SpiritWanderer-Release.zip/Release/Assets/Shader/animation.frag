#version 450 core
precision highp float;

// in variables
layout(location = 0) in vec3 vColor;
layout(location = 1) in vec2 vTextureCoordinates;

// out variables
layout(location = 0) out vec4 fFragClr;

// uniform variables
uniform sampler2D uTexture;
uniform vec3 uColor;

void main()
{
    vec4 textureColor = texture(uTexture, vTextureCoordinates);
    fFragClr = textureColor * vec4(uColor, 1.0);
}
