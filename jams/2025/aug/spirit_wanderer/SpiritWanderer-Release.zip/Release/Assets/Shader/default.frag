#version 450 core

// in variables
layout(location = 0) in vec3 vColor;
layout(location = 1) in vec2 vTextureCoordinates;

// out variables
layout(location = 0) out vec4 fFragClr;

// uniform variables
uniform sampler2D uTex2d;

void main()
{
    fFragClr = texture(uTex2d, vTextureCoordinates);
}
