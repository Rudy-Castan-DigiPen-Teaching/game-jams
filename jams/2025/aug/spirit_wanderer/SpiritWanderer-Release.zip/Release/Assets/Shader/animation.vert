#version 450 core

// in variables
layout(location = 0) in vec2 aVertexPosition;
layout(location = 1) in vec3 aVertexColor;
layout(location = 2) in vec2 aTextureCoordinate;

// out variables
layout(location = 0) out vec3 vColor;
layout(location = 1) out vec2 vTextureCoordinates;

// uniform variables
uniform mat3 uModelToNDC;
uniform vec2 uTextureCoordinate; // x, y, width, height of the frame in texture coordinates
uniform vec2 uTexSize;

void main()
{
    gl_Position = vec4(vec2(uModelToNDC * vec3(aVertexPosition.x, aVertexPosition.y, 1.f)), 0.0, 1.0);
    vColor      = aVertexColor;
    vTextureCoordinates = aTextureCoordinate * (uTexSize - uTextureCoordinate) + uTextureCoordinate; 
    // Calculate the correct texture coordinates for the frame
}
