Player player;
Dice dice;

int[] Dice_Value = new int[10];
int[] normal = {1,2,3,4,5,6};
int[] red = {1,1,1,6,6,6};
int[] blue = {3,3,3,3,4,4};
int attack = 0;
int a = 0,y = 0,z = 0,l = 0;
int enemy = 0;
int enemy_life = 3;
int[] enemy_attack= {int(random(6,9)), int(random(11,13)),int(random(15,17 ))};;
int nowEnemyattack = 0;

boolean background1 = true;
boolean background2,background3,background4= false;

PImage plus;
PImage minus;

int selectDice = 0;
int[] inventory = new int[10];

int dice_red = 0;
int dice_blue = 0; 
int dice_normal = 0;

PImage dragon;

boolean player1 = true;
boolean flame_small = false;
boolean flame_big = false;

PImage flame2;
PImage flame1;
int p,o=0;
float v,u = 0;

boolean trigger = true;

void setup(){
  noStroke();
  size(1500,900);
  player = new Player();
  dice = new Dice();
  background1 = true;
  plus = loadImage("C:\\Users\\USER\\Downloads\\plus.png");
  minus = loadImage("C:\\Users\\USER\\Downloads\\minus.png");
  dragon = loadImage("C:\\Users\\USER\\Downloads\\red dragon.png");
  
  flame1 = loadImage("C:\\Users\\USER\\Downloads\\New Piskel-1.png (1).png");
  flame2 = loadImage("C:\\Users\\USER\\Downloads\\c4ae26bf-4fb1-4934-8d2a-ceb0d5df7590 (1).png");
  p = 300;
  o = 300;
  u = 5;
  v = 1;
}

void draw(){
  //배경1
  //시작 화면
  if(background1 == true){
    background(255);
    fill(0,255,0);
    quad(500,350,1000,350,1000,550,500,550);
    fill(0);
    textSize(100);
    text("start",650,475);
    if (mouseX > 500 && mouseX <1000 && mouseY > 350 && mouseY <550){
      if(mousePressed == true){
        background1 = false;
        background2 = true;
        mousePressed = false;
      }
    }
  }
  
  //배경2
  //주사위 선택
  if(background2 == true){
    background(48,220,248);
    fill(0,255,0);
    quad(0,550,1500,550,1500,900,0,900);
    
    fill(0,80);
    quad(0,0,1500,0,1500,900,0,900);
    dice.draw_2();
    
    //플마 버튼
    quad(20,520,220,520,220,600,20,600);
    quad(521,520,720,520,720,600,521,600);
    quad(1021,520,1220,520,1220,600,1021,600);
    
    //플마 중간선
    quad(120,520,121,520,121,600,120,600);
    quad(620,520,621,520,621,600,620,600);
    quad(1120,520,1121,520,1121,600,1120,600);
    
    //플러스 마이너스
    image(plus,40,530,60,60);
    image(minus,140,530,60,60);
    image(plus,540,530,60,60);
    image(minus,640,530,60,60);
    image(plus,1040,530,60,60);
    image(minus,1140,530,60,60);
    
    //결정
    fill(0,255,0);
    quad(1250,700,1400,700,1400,800,1250,800);
    fill(0);
    textSize(50);
    text("start",1275,770);
    
    //주사위 추가
    if(mouseX > 20 && mouseX < 120 && mouseY > 520 && mouseY < 600){
      if(mousePressed == true){
        if(inventory[9] == 0 && a <= 9){
          inventory[selectDice] = 1;
          selectDice++;
          mousePressed = false;
        }
      }
    }
    
    if(mouseX > 521 && mouseX < 620 && mouseY > 520 && mouseY < 600){
      if(mousePressed == true){
        if(inventory[9] == 0){
          inventory[selectDice] = 2;
          selectDice++;
          mousePressed = false;
        }
      }
    }
    
    if(mouseX > 1021 && mouseX < 1120 && mouseY > 520 && mouseY < 600){
      if(mousePressed == true){
        if(inventory[9] == 0){
          inventory[selectDice] = 3;
          selectDice++;
          mousePressed = false;
        }
      }
    }
    println(inventory);
    
    //주사위 삭제
    if(mouseX > 121 && mouseX < 220 && mouseY > 520 && mouseY < 600){
      if(mousePressed == true){
        for(int i = inventory.length-1; i >= 0;i--){
          if(inventory[i] == 1){
            inventory[i] = 0;
            selectDice = i;
            
            for(int j = i; j <inventory.length; j++){
              if(j+1 <= 9 && inventory[j+1] != 0){
                inventory[j] = inventory[j+1];
                inventory[j+1] = 0;
                selectDice =  j+1;
                mousePressed = false;
              }
            }
            mousePressed = false;
            break;
          }
          mousePressed = false;
        }
      }
    }
    
    if(mouseX > 621 && mouseX < 720 && mouseY > 520 && mouseY < 600){
      if(mousePressed == true){
        for(int i = inventory.length - 1; i >= 0;i--){
          if(inventory[i] == 2){
            inventory[i] = 0;
            selectDice = i;
            for(int j = i; j <inventory.length; j++){
              if(j+1 <= 9 && inventory[j+1] != 0){
                inventory[j] = inventory[j+1];
                inventory[j+1] = 0;
                selectDice =  j+1;
                mousePressed = false;
              }
            }
            mousePressed = false;
            break;
          }
          mousePressed = false;
        }
      }
    }
    if(mouseX > 1121 && mouseX < 1220 && mouseY > 520 && mouseY < 600){
      if(mousePressed == true){
        for(int i = inventory.length - 1; i >= 0;i--){
          if(inventory[i] == 3){
            inventory[i] = 0;
            selectDice = i;
            for(int j = i; j <inventory.length; j++){
              if(j+1 <= 9 && inventory[j+1] != 0){
                inventory[j] = inventory[j+1];
                inventory[j+1] = 0;
                selectDice =  j+1;
                mousePressed = false;
              }
            }
            mousePressed = false;
            break;
          }
          mousePressed = false;
        }
      }
    }
    
    
    for(int i = 0; i < inventory.length;i++){
      if(inventory[i] == 1){
         dice_normal +=1; 
      }
      
      if(inventory[i] == 2){
         dice_blue +=1; 
      }
      
      if(inventory[i] == 3){
         dice_red +=1; 
      }
    }
    
    if(dice_normal != 0){
      dice.normal(0,0,100);
      textSize(50);
      text("x" + dice_normal,100,50);
    }
      
    if(dice_blue != 0){
      dice.blue(150,0,100);
      textSize(50);
      text("x" + dice_blue,250,50);
    }
      
    if(dice_red != 0){
      dice.red(300,0,100);
      textSize(50);
      text("x" +dice_red,400,50);
    }

    
    
    
    dice_normal=0;
    dice_blue=0;
    dice_red=0;
    //결정
    if(mouseX > 1250 && mouseX < 1400 && mouseY > 700 && mouseY < 800){
      if(mousePressed == true){
        background3 = true;
        background2 = false;
        mousePressed = false;
      }
    }
  }
  
  
  

  
  //배경3
  if (background3 == true){
    
    background(48,220,248);
    fill(0,255,0);
    quad(0,600,1500,600,1500,900,0,900);
    if(player1 == true){
      player.draw1();
    }
    if(player1 == false){
      player.draw2();
    }
    //if(flame_small == true){
    //  image(flame1,300,300,150,150);
    //}
    
      println();
    
    dice.draw_1();
    fill(255,0,0);
    quad(1100,700,1300,700,1300,800,1100,800);
    fill(0);
    textSize(50);
    text("attack",1140,750);
    fill(255,0,0);
    
    
  //주사위 사용
    //use_normal();
    //use_red();
    //use_blue();
    image(dragon, 1050,270,370,370);
    println(Dice_Value);
    println(a); 
    
    //선택한 주사위
    for(int i = 0; i < inventory.length;i++){
      if(inventory[i] == 1){
         dice_normal +=1; 
      }
      
      if(inventory[i] == 2){
         dice_blue +=1; 
      }
      
      if(inventory[i] == 3){
         dice_red +=1; 
      }
    } 
    
    if(dice_normal != 0){
      dice.normal(0,0,100);
      textSize(50);
      text("x" + dice_normal,100,50);
    }
      
    if(dice_blue != 0){
      dice.blue(150,0,100);
      textSize(50);
      text("x" + dice_blue,250,50);
    }
      
    if(dice_red != 0){
      dice.red(300,0,100);
      textSize(50);
      text("x" +dice_red,400,50);
    }
    
    dice_normal=0;
    dice_blue=0;
    dice_red=0;
    //if (trigger == true){
    for ( int i = 0; i < inventory.length; i++){
      if (inventory[i] == 1 ){
        use_normal();
      }
      
      if (inventory[i] == 2 ){
        use_blue();
      }
      
      if (inventory[i] == 3 ){
        use_red();
      }
    }
    //}
    
    
   //주사위 위에 띠우기
    for( int i = 0; i < Dice_Value.length; i++){
      if (Dice_Value[i] != 0){
        dice.DrawDice(Dice_Value[i],120*i,110);
      }
    }
  
    //적 체력  공격력
    if (enemy_life == 3 ){
      nowEnemyattack = enemy_attack[0];
     textSize(80);
     text(enemy_attack[0],1150,270);
    }
    if (enemy_life == 2 ){
      nowEnemyattack = enemy_attack[1];
      textSize(80);
      text(enemy_attack[1],1150,270);
    }
    if (enemy_life == 1 ){
      nowEnemyattack = enemy_attack[2];
      textSize(80);
      text(enemy_attack[2],1150,270);
    }
    
    
  //공격 트리거
 //if (trigger == true){
    if (mouseX > 1000 && mouseX < 1400 && mouseY > 650 && mouseY < 800){
      if (mousePressed == true){
        mousePressed = false;
        trigger = false;
       // player1 =false;
       // flame_small = true;
        
        for (int i = 0; i < Dice_Value.length; i++) {
          attack = attack + Dice_Value[i]; 
        }
        if(attack < nowEnemyattack){
          fill(255,0,0);
          rect(0,0,1500,900);
          fill(0);
          textSize(250);
          text("you lose",250,450);
          textSize(100);
          text("Restart",600,700);
          background3 = false;
          background4 = true;
          mousePressed = false;
        }
        
        if(attack >= nowEnemyattack){
          enemy_life -= 1;
          attack = 0;
          flame_small = true;
          player1 =false;
          for(int i  = 0; i <inventory.length; i++){
            if (inventory[i] == 0){
              inventory[i] = int(random(1,3));
              break;
            }
          }
        }
        
          for(int i = 0; i <Dice_Value.length; i++){
            Dice_Value[i] = 0;
            a=0;
            trigger = true;
        }
        println(attack);
      }
    }
  //}
    if (flame_big == true){
      image(flame2,850,100,700,700);
    }
    
    if(flame_small == true){
      image(flame1,p,o,150,150);
      p +=u;
      //o +=v;
    }
      if (p >=1000 ){
        flame_small = false;
        flame_big =true;
        if (p >= 1000){
         p +=u;
        }
      }
      if (p >=1200 ){
        flame_big =false;
        player1 = true;
        p = 300;
        println("on");
      }
    }
    
    if (enemy_life == 0){
      rect(0,0,1500,900);
      background3 = false;
      background4 = true;
      fill(255,0,0);
      rect(0,0,1500,900);
      fill(0);
      textSize(300);
      text("you win",250,450);
      textSize(100);
      text("Restart",600,700);
    }
    
    if( background4 == true){
    if(mousePressed == true){
      for(int i = 0; i < inventory.length;i++){
        inventory[i] = 0;
      }
      mousePressed = false;
      background4 = false;
      background1 = true;
      enemy_life = 3;
      
    }
}
  
    
    
    
    
    
    
    
    
  
  println(enemy_life);
  println(a);
  println(inventory);
  
}
  


//빨간주사위
void use_red(){
  if (mousePressed == true) {
    //주사위 수 10이상될때 초기화
    if (a == 10){
      a = 0;
      for( int i = 0; i < Dice_Value.length; i++){
        Dice_Value[i] = 0;
      }
    }
    //마우스 클릭 범위
    if (mouseX > 360 && mouseX < 510 && mouseY > 700 && mouseY < 850){
      y = int(random(1,7));
      z = red[y-1];
      //주사위 값저장
      Dice_Value[a] = z;
      //주사위 수 더하기
      ++a;
      println( z = red[y-1]);
       for(int i = inventory.length - 1; i >= 0;i--){
          if(inventory[i] == 3){
            inventory[i] = 0;
            selectDice = i;
            for(int j = i; j <inventory.length; j++){
              if(j+1 <= 9 && inventory[j+1] != 0){
                inventory[j] = inventory[j+1];
                inventory[j+1] = 0;
                selectDice =  j+1;
                mousePressed = false;
              }
            }
            mousePressed = false;
            break;
          }
          mousePressed = false;
        }
    }
    
  }
}


//파란주사위
void use_blue(){
  if (mousePressed == true) {
    //주사위 수 10이상될때 초기화
    if (a == 10){
      a = 0;
      for( int i = 0; i < Dice_Value.length; i++){
        Dice_Value[i] = 0;
      }
    }
    //마우스 클릭 범위
    if (mouseX > 190 && mouseX < 340 && mouseY > 700 && mouseY < 850){
      y = int(random(1,7));
      z = blue[y-1];
      //주사위 값저장
      Dice_Value[a] = z;
       //주사위 수 더하기
      ++a;
      println( z = blue[y-1]);
      for(int i = inventory.length - 1; i >= 0;i--){
          if(inventory[i] == 2){
            inventory[i] = 0;
            selectDice = i;
            for(int j = i; j <inventory.length; j++){
              if(j+1 <= 9 && inventory[j+1] != 0){
                inventory[j] = inventory[j+1];
                inventory[j+1] = 0;
                selectDice =  j+1;
                mousePressed = false;
              }
            }
            mousePressed = false;
            break;
          }
          mousePressed = false;
        }
    }
    
  }
}


//흰 주사위
void use_normal(){
  if (mousePressed == true) {
    //주사위 수 10이상될때 초기화
    if (a == 10){
      a = 0;
      for( int i = 0; i < Dice_Value.length; i++){
        Dice_Value[i] = 0;
      }
    }
    //마우스 클릭 범위
    if (mouseX > 20 && mouseX < 170 && mouseY > 700 && mouseY < 850){
      y = int(random(1,7));
      z = normal[y-1];
      //주사위 값저장
      Dice_Value[a] = z;
       //주사위 수 더하기
      ++a;
      println( z = normal[y-1]);
      for(int i = inventory.length - 1; i >= 0;i--){
          if(inventory[i] == 1){
            inventory[i] = 0;
            selectDice = i;
            for(int j = i; j <inventory.length; j++){
              if(j+1 <= 9 && inventory[j+1] != 0){
                inventory[j] = inventory[j+1];
                inventory[j+1] = 0;
                selectDice =  j+1;
                mousePressed = false;
              }
            }
            mousePressed = false;
            break;
          }
          mousePressed = false;
        }
    }
  }

}





class Player{
  PImage player_wizard1;
  PImage player_wizard2;
  PImage flame2;
  PImage flame1;
  int p,o,i,u;
  Player(){
    player_wizard1 = loadImage("C:\\Users\\USER\\Downloads\\player white 1.png");
    player_wizard1.resize(300,300);
    player_wizard2 = loadImage("C:\\Users\\USER\\Downloads\\player white 2.png");
    player_wizard2.resize(300,300);

  
  }
  
  void draw1(){
    image(player_wizard1,100,350);
  }
  void draw2(){
    image(player_wizard2,100,350);
  }

  
}

class Dice{
  PImage Dice1;
  PImage Dice2;
  PImage Dice3;
  PImage Dice4;
  PImage Dice5;
  PImage Dice6;
  PImage Dice1_6;
  PImage Dice3_4;
  PImage DiceNormal;
  PImage [] Dice_Value_list = new PImage[6];
  
  Dice(){
    Dice_Value_list[0] =loadImage("C:\\Users\\USER\\Downloads\\dice 1.png");
    Dice_Value_list[1] =loadImage("C:\\Users\\USER\\Downloads\\dice 2.png");
    Dice_Value_list[2] =loadImage("C:\\Users\\USER\\Downloads\\dice 3.png");
    Dice_Value_list[3] =loadImage("C:\\Users\\USER\\Downloads\\dice 4.png");
    Dice_Value_list[4] =loadImage("C:\\Users\\USER\\Downloads\\dice 5.png");
    Dice_Value_list[5] =loadImage("C:\\Users\\USER\\Downloads\\dice 6.png");
    Dice1 = loadImage("C:\\Users\\USER\\Downloads\\dice 1.png");
    Dice2 = loadImage("C:\\Users\\USER\\Downloads\\dice 2.png");
    Dice3 = loadImage("C:\\Users\\USER\\Downloads\\dice 3.png");
    Dice4 = loadImage("C:\\Users\\USER\\Downloads\\dice 4.png");
    Dice5 = loadImage("C:\\Users\\USER\\Downloads\\dice 5.png");
    Dice6 = loadImage("C:\\Users\\USER\\Downloads\\dice 6.png");
    Dice1_6 = loadImage("C:\\Users\\USER\\Downloads\\1 6 dice.png");
    Dice3_4 = loadImage("C:\\Users\\USER\\Downloads\\3 4 dice.png");
    DiceNormal = loadImage("C:\\Users\\USER\\Downloads\\normal dice.png");
    Dice_Value_list[0].resize(100,100);
    Dice_Value_list[1].resize(100,100);
    Dice_Value_list[2].resize(100,100);
    Dice_Value_list[3].resize(100,100);
    Dice_Value_list[4].resize(100,100);
    Dice_Value_list[5].resize(100,100);
 
    
    Dice1.resize(100,100);
    Dice2.resize(100,100);
    Dice3.resize(100,100);
    Dice4.resize(100,100);
    Dice5.resize(100,100);
    Dice6.resize(100,100);
    Dice1_6.resize(150,150);
    Dice3_4.resize(150,150);
    
  }
  void red(int x,int y,int l){
    image(Dice1_6, x , y, l, l);
  }
  void blue(int x,int y,int l){
    image(Dice3_4, x , y, l, l);
  }
  void normal(int x,int y,int l){
    image(DiceNormal, x, y, l, l);
  }
  
  
  void draw_1(){
    image(Dice1_6,360,700);
    image(Dice3_4,190,700);
    image(DiceNormal,20,700,150,150); 
  }
  
  void draw_2(){
    image(DiceNormal,20,300,200,200);
    image(Dice3_4,521,300,200,200);
    image(Dice1_6,1021,300,200,200);
    
  }
  
  void draw_3(int x, int y ,int l){
   image(DiceNormal, x, y, l, l);
   image(Dice3_4, x +300, y, l, l);
   image(Dice1_6, x +600, y, l, l);
  }
  
  void DrawDice(int number,int x ,int y){
    image(Dice_Value_list[number-1],x,y);
  }
    
  //void show_dice_value(int x){
  //  for (int i = 0; i < 6;i++){
  //    if (i == x - 1){
  //      image(Dice_Value_list[i], 120*x,0);
  //    }
  //  }
  //}
}




  
