Team OmegaRudy (Seungju Song & Chanwoong Moon)

A bear is coming to your home, you must find items and protect your home and yourself in few seconds.

This game has 2 phase.

The first phase is finding items in home, just move to next room with A, D buttons and click it to collect.

Then, in second phase, fight with bear. 
In this phase, player will fight will the item it found.
Such as pot lid, broom, and so on.
